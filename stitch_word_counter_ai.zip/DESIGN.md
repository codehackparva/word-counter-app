---
name: Linguistic Precision
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#464555'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#414855'
  on-tertiary: '#ffffff'
  tertiary-container: '#59606e'
  on-tertiary-container: '#d4dbeb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#dce2f3'
  tertiary-fixed-dim: '#c0c7d6'
  on-tertiary-fixed: '#151c27'
  on-tertiary-fixed-variant: '#404754'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Noto Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  stat-value:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  container-max: 1120px
  gutter: 20px
---

## Brand & Style
This design system centers on a **Minimalist** and utility-focused aesthetic tailored for high-performance text analysis. The brand personality is professional, functional, and unobtrusive, prioritizing the user's content over decorative elements. 

The target audience includes writers, translators, and developers working with Indian languages who require a tool that handles complex scripts with absolute clarity. The emotional response should be one of "digital calm"—a clean, generous workspace that reduces cognitive load during intense editing or analysis tasks. 

Key visual principles include:
- **Generous Whitespace:** Promoting focus on the text input and data output.
- **Utilitarian Elegance:** Every element serves a specific analytical purpose.
- **Soft Neutrals:** A background-first approach that makes the active workspace feel elevated.

## Colors
The palette is built on a foundation of "Off-White" and "High-Ink" neutrals to mimic the legibility of high-quality print.

- **Primary (#4F46E5):** Used sparingly for primary actions, active states, and critical data highlights.
- **Surface & Background:** The main application background uses #FAFAFA to reduce screen glare, while active cards and text areas use #FFFFFF to create a subtle layered effect.
- **Typography:** #1A1A1A provides high-contrast readability for body text and results, while #6B7280 is reserved for secondary metadata and labels.
- **Borders:** A consistent #E5E7EB is used for structural definition without creating visual noise.

## Typography
This design system utilizes a dual-font strategy to balance UI precision with linguistic accuracy.

- **UI Elements (Inter):** Used for navigation, labels, buttons, and numerical data. Inter’s tall x-height ensures clarity in small functional components.
- **Content & Analysis (Noto Sans):** Used for all user-generated text and analysis results. Noto Sans is specifically chosen for its best-in-class support for Indic scripts (Devanagari, Tamil, Gujarati, etc.), ensuring complex ligatures and glyphs render perfectly.
- **Hierarchy:** Use `stat-value` for word and character counts to provide immediate visual feedback. `body-lg` is preferred for the primary text editor to improve long-form reading comfort.

## Layout & Spacing
The layout follows a **Fixed Grid** model for the desktop to maintain a readable line length for text analysis, while transitioning to a **Fluid Grid** for mobile devices.

- **Desktop:** Centralized 12-column container (max-width 1120px). The main text input occupies 8 columns, while the analysis sidebar or stats pills occupy 4 columns.
- **Spacing Rhythm:** Based on a 4px baseline. Use 16px (`md`) for internal card padding and 24px (`lg`) for vertical spacing between sections.
- **Mobile Adaptivity:** On screens below 768px, the layout stacks vertically. The analysis sidebar moves below the text input, and the primary stats pills become a horizontal scrolling row at the top of the viewport.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows** rather than heavy borders.

- **Z-0 (Background):** #FAFAFA. The canvas.
- **Z-1 (Cards/Editor):** #FFFFFF with a 1px border of #E5E7EB. This is the primary work surface.
- **Shadows:** Use a very soft, diffused shadow for the main editor and analysis cards: `0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.03)`.
- **Interactions:** On hover, interactive cards should lift slightly by increasing the shadow spread and reducing opacity. No heavy elevation is used, keeping the tool feeling light and fast.

## Shapes
The shape language is modern and approachable. 

- **Primary Radius:** 0.5rem (8px) for standard components like small buttons and input fields.
- **Large Radius (rounded-lg):** 1rem (16px) for the primary text editor container and main analysis cards. This softer corner helps the tool feel more like a friendly utility and less like a legacy spreadsheet.
- **Pill Shapes:** Used exclusively for "Status Pills" and "Language Tags" to differentiate them from actionable buttons.

## Components
- **Text Editor:** A large, borderless textarea within a `rounded-lg` card. Focus states should be indicated by a subtle 2px Indigo (#4F46E5) outer glow.
- **Stat Pills:** Compact, non-interactive containers with a light grey background (#F3F4F6) and bold Inter typography for the count.
- **Primary Buttons:** Solid Indigo (#4F46E5) with white text, 8px corner radius. Used for "Analyze" or "Copy" actions.
- **Collapsible Cards:** For detailed analysis (e.g., Keyword Density, Sentiment). Use a chevron icon on the right; the header remains visible while the content can be toggled to save vertical space.
- **Language Switcher:** A clean dropdown using `label-md` Inter font, allowing users to force a specific script rendering engine if auto-detection is not required.
- **Checkboxes:** Square with a 4px radius, filling with Indigo when active, used for toggling specific analysis metrics (e.g., "Ignore stop words").